    <!-- menú -->
    <div class="container mt-1 menu-admin bordee">
        <a href="index.php" class="boton-inversion">Inversión</a>
        <a href="gastos.php" class="boton-gastos">Gastos</a>
        <a href="venta.php" class="boton-venta">Venta</a>
    </div>

   