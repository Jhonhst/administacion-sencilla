    <!-- footer -->
    <br>
    <br>
    <br>
    </div>
    <div class="footer">

    </div>
    <script src="librerias/bootstarp 4/js/1jquery-3.3.1.slim.min.js"></script>
    <script src="librerias/bootstarp 4/js/2popper.min.js"></script>
    <script src="librerias/bootstarp 4/js/3bootstrap.min.js"></script>
    <script src="librerias/jquery 3/jquery-3.3.1.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>